%     Demo for running L2S code
%     Code developed by Suvadip Mukherjee, VIVA Lab, University of Virginia
%     Reference
%         [1] Mukherjee, S.; Acton, S., "Region based segmentation in presence 
%         of intensity inhomogeneity using Legendre polynomials," Signal Processing Letters, 
%         IEEE , vol.PP, no.99, pp.1,1
% (c) Copyright Suvadip Mukherjee (sm5vp@virginia.edu) 
%     This program can be used for non-commercial purposes. Please cite [1] if you are using this code
%     for your research.

clc
clear
Img              = imread('example.png');
prop.Img         = Img;
prop.n_regions   = 1;     % Number of regions you want
prop.mask_type   = 'ellipse';
prop.img_magnify = 200;

init_mask        = initRegions(prop);

max_iter = 1000;   % upper bound on number of iterations
nu       = 0.3;    % Contour smoothing term -- see eq (3) in paper
m        = 0;      % Highest polynomial degree -- see Sec. III paper, m=0 is Chan-Vese
lambda   = 0.5;    % L2 coefficient -- see eq (3) paper
color    = 'w';    % color of the contour
convg_thresh = 1;  % determines convergence criteria

[bin_seg,convg_phi,its] = runL2S(Img,init_mask,max_iter,nu,m,lambda,color,convg_thresh);

